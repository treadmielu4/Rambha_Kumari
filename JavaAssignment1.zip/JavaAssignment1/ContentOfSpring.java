package project;



public class ContentsOfSpring {

	

	
	    
		  public static void main(String[] args)
		    {
		        String str = "Java Program.";

		        char[] arr = str.toCharArray();

		       
		        System.out.println(arr);
		    }
		}
