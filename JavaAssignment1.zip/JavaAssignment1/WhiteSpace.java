package circle;



public class WhiteSpace {

	    public static void main(String args[]) 
	    { 
	        String str1 = "  Hello World  "; 
	        System.out.println(str1); 
	        System.out.println(str1.trim()); 
	  
	        String str2 = "      Hey  there    Jay!!!      "; 
	        System.out.println(str2); 
	        System.out.println(str2.trim()); 
	    } 
	} 